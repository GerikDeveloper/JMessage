package com.ultima.democlient001;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class CreateGroup extends AppCompatActivity {
    private Context context;
    private List<Long> MemberIds;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_group_activity);
        getSupportActionBar().hide();
        context = getApplicationContext();
        MemberIds = new ArrayList<>();
        Button CreateGroup = findViewById(R.id.create_group_end_button);
        ImageButton AddMemberButton = findViewById(R.id.add_member_button);
        EditText EditICN = findViewById(R.id.edit_icn_create_group);
        TextView MembersText = findViewById(R.id.icn_added_members);
        EditText EditGroupICN = findViewById(R.id.edit_group_icn);
        AddMemberButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ICN = EditICN.getText().toString();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        MainActivity.MainAPIExecutor.stopPinging();
                        byte[] MemberId = MainActivity.MainAPIExecutor.ExecuteGetClientId(ICN);
                        if(MemberId != null){
                            MemberIds.add(ByteOperations.BytesToLong(MemberId));
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    String latest = MembersText.getText().toString();
                                    MembersText.setText(String.format("%s\n\n%s", latest, ICN));
                                }
                            });
                        }
                        MainActivity.MainAPIExecutor.startPinging();
                    }
                }).start();
            }
        });
        CreateGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String groupICN = EditGroupICN.getText().toString();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        MainActivity.MainAPIExecutor.stopPinging();
                        if(MainActivity.MainAPIExecutor.ExecuteGetGroupId(ByteOperations.Get_Bytes_By_String_UTF_8(groupICN)) == null){
                            long[] MemberIdsArray = new long[MemberIds.size()];
                            for(int RdMembers = 0; RdMembers < MemberIds.size(); RdMembers++){
                                MemberIdsArray[RdMembers] = MemberIds.get(RdMembers);
                            }
                            byte result = MainActivity.MainAPIExecutor.ExecuteCreateGroup(groupICN, "", 1, MainActivity.MainAPIExecutor.getId(), MemberIdsArray);
                            if(result == LocalCodes.SUCCESS){
                                MainActivity.MainAPIExecutor.startPinging();
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
                                        new Thread(new Runnable() {
                                            @Override
                                            public void run() {
                                                try {
                                                    Thread.sleep(1000);
                                                    MainAuthActivity.PTR.addGroup(groupICN);
                                                }   catch(Exception UnknownException){}
                                            }
                                        }).start();
                                        Intent intent = new Intent(CreateGroup.this, MainAuthActivity.class);
                                        startActivity(intent);
                                    }
                                });
                            }
                            else{
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(context, "Unknown error", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }
                        }
                        else{
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(context, "Error, group ICN taken", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                        MainActivity.MainAPIExecutor.startPinging();
                    }
                }).start();
            }
        });
    }
}
