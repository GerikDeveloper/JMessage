package com.ultima.democlient001;

public class LocalCodes {
    public static final byte SUCCESS = 0;
    public static final byte UNKNOWN_ERROR = 1;
    public static final byte IO_ERROR = 2;
    public static final byte FORBIDDEN = 3;
    public static final byte ICN_TAKEN = 4;
    public static final byte EMAIL_TAKEN = 5;
}
