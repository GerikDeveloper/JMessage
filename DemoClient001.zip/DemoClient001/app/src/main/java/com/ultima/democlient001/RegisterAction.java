package com.ultima.democlient001;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterAction extends AppCompatActivity {
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_action);
        getSupportActionBar().hide();
        context = getApplicationContext();
        Button Register = findViewById(R.id.continue_from_register);
        EditText EditICN = findViewById(R.id.edit_icn_register);
        EditText EditPassword = findViewById(R.id.edit_password_register);
        EditText EditEmail = findViewById(R.id.edit_email_register);
        ProgressBar PBar = findViewById(R.id.register_waiting_bar);
        View.OnClickListener RegisterListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ICN = EditICN.getText().toString();
                String Password = EditPassword.getText().toString();
                String Email = EditEmail.getText().toString();
                if(!(ICN.equals("") || Password.equals("") || Email.equals(""))){
                    PBar.setVisibility(ProgressBar.VISIBLE);
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            MainActivity.MainAPIExecutor.stopPinging();
                            byte regResult = MainActivity.MainAPIExecutor.ExecuteRegister(ICN, Password, Email, "");
                            if(regResult == LocalCodes.SUCCESS){
                                MainActivity.MainAPIExecutor.startPinging();
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        PBar.setVisibility(ProgressBar.INVISIBLE);
                                        Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(RegisterAction.this, MainAuthActivity.class);
                                        startActivity(intent);
                                    }
                                });
                            }
                            else{
                                MainActivity.MainAPIExecutor.ExecuteDisconnect();
                                MainActivity.MainAPIExecutor.StopProcess();
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        PBar.setVisibility(ProgressBar.INVISIBLE);
                                        String Message;
                                        if(regResult == LocalCodes.ICN_TAKEN)   Message = "Error, ICN taken";
                                        if(regResult == LocalCodes.EMAIL_TAKEN)   Message = "Error, Email taken";
                                        else Message = "Error, please try again";
                                        Toast.makeText(context, Message, Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(RegisterAction.this, MainActivity.class);
                                        startActivity(intent);
                                    }
                                });
                            }
                        }
                    }).start();
                }
            }
        };
        Register.setOnClickListener(RegisterListener);
    }
}
