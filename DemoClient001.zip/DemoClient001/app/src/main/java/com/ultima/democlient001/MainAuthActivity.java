package com.ultima.democlient001;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainAuthActivity extends AppCompatActivity{
    private Context context;
    private RecyclerView GroupsView;
    private GroupItemAdapter itemAdapter;
    private List<String> itemsICN = new ArrayList<>();
    public static MainAuthActivity PTR;

    public void addGroup(String ICN){
        itemsICN.add(ICN);
        itemAdapter = new GroupItemAdapter(itemsICN);
        GroupsView.setAdapter(itemAdapter);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_auth_activity);
        getSupportActionBar().hide();
        context = getApplicationContext();
        PTR = this;
        ImageButton AddButton = findViewById(R.id.main_add_button);
        AddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainAuthActivity.this, CreateGroup.class);
                startActivity(intent);
            }
        });
        ImageButton SearchButton = findViewById(R.id.main_search_button);
        SearchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainAuthActivity.this, SearchGroupActivity.class);
                startActivity(intent);
            }
        });
        ImageButton BackButton = findViewById(R.id.main_back_to_groups_button);
        GroupsView = findViewById(R.id.groups_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        GroupsView.setLayoutManager(layoutManager);
        itemAdapter = new GroupItemAdapter(itemsICN);
        GroupsView.setAdapter(itemAdapter);
    }
}
