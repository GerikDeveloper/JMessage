package com.ultima.democlient001;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Context context;
    public static APIExecutor MainAPIExecutor;
    public static String ip;
    public static int port;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        context = getApplicationContext();
        EditText Ip = findViewById(R.id.edit_server_ip);
        EditText Port = findViewById(R.id.edit_server_port);
        Button Continue = findViewById(R.id.continue_from_set_server);
        ProgressBar PBar = findViewById(R.id.server_connect_waiting_bar);
        View.OnClickListener onContinue = view -> {
            if (!Ip.getText().toString().equals("") && !Port.getText().toString().equals("")) {
                ip = Ip.getText().toString();
                port = Integer.parseInt(Port.getText().toString());
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                PBar.setVisibility(ProgressBar.VISIBLE);
                            }
                        });
                        MainAPIExecutor = new ServerConnection(ip, port).HandShake(null);
                        if(MainAPIExecutor == null){
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    PBar.setVisibility(ProgressBar.INVISIBLE);
                                    Intent intent = new Intent(MainActivity.this, EnterServerPassword.class);
                                    startActivity(intent);
                                }
                            });
                        }
                        else {
                            MainAPIExecutor.startPinging();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    PBar.setVisibility(ProgressBar.INVISIBLE);
                                    Toast.makeText(context, "Successfully connected", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(MainActivity.this, ChooseAuthorizeAction.class);
                                    startActivity(intent);
                                }
                            });
                        }
                    }
                }).start();
            }
        };
        Continue.setOnClickListener(onContinue);
    }
}