package com.ultima.democlient001;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EnterServerPassword extends AppCompatActivity {
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.enter_server_password);
        getSupportActionBar().hide();
        context = getApplicationContext();
        EditText PasswordEditor = findViewById(R.id.edit_server_password);
        Button ContinueButton = findViewById(R.id.continue_from_enter_server_password);
        ProgressBar PBar = findViewById(R.id.waiting_server_password_correct);
        View.OnClickListener Continuer = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Password = PasswordEditor.getText().toString();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                PBar.setVisibility(ProgressBar.VISIBLE);
                            }
                        });
                        MainActivity.MainAPIExecutor = new ServerConnection(MainActivity.ip, MainActivity.port).HandShake(Password);
                        if(MainActivity.MainAPIExecutor == null){
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    PBar.setVisibility(ProgressBar.INVISIBLE);
                                    Toast.makeText(context, "Failed to connect", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(EnterServerPassword.this, MainActivity.class);
                                    startActivity(intent);
                                }
                            });
                        }
                        else{
                            MainActivity.MainAPIExecutor.startPinging();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    PBar.setVisibility(ProgressBar.INVISIBLE);
                                    Toast.makeText(context, "Successfully connected", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(EnterServerPassword.this, ChooseAuthorizeAction.class);
                                    startActivity(intent);
                                }
                            });
                        }
                    }
                }).start();
            }
        };

        ContinueButton.setOnClickListener(Continuer);

    }
}
