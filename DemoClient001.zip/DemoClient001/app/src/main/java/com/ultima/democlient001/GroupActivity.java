package com.ultima.democlient001;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class GroupActivity extends AppCompatActivity{
    private Context context;
    public static String groupICN;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.group_activity);
        getSupportActionBar().hide();
        context = getApplicationContext();
        ImageButton sendButton = findViewById(R.id.send_message_button);
        EditText editMSG = findViewById(R.id.edit_message);
        TextView MSGText = findViewById(R.id.messages_text);
        Button UpdMSGButton = findViewById(R.id.update_messages_button);
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data = editMSG.getText().toString();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        MainActivity.MainAPIExecutor.stopPinging();
                        byte[] groupId = MainActivity.MainAPIExecutor.ExecuteGetGroupId(ByteOperations.Get_Bytes_By_String_UTF_8(groupICN));
                        if(groupId != null){
                            MainActivity.MainAPIExecutor.ExecuteSendMSG(ByteOperations.BytesToLong(groupId), data);
                        }
                        MainActivity.MainAPIExecutor.startPinging();
                    }
                }).start();
            }
        });
        UpdMSGButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data = editMSG.getText().toString();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        MainActivity.MainAPIExecutor.stopPinging();
                        byte[] groupId = MainActivity.MainAPIExecutor.ExecuteGetGroupId(ByteOperations.Get_Bytes_By_String_UTF_8(groupICN));
                        if(groupId != null){
                            long[] MSGIds = MainActivity.MainAPIExecutor.ExecuteGetMSGIds(ByteOperations.BytesToLong(groupId));
                            if(MSGIds != null) {
                                StringBuilder result = new StringBuilder();
                                for (long MSGId : MSGIds) {
                                    TextMSG msg = MainActivity.MainAPIExecutor.ExecuteGetMSG(ByteOperations.BytesToLong(groupId), MSGId);
                                    if(msg != null){
                                        String senderICN = ByteOperations.Get_String_UTF_8(MainActivity.MainAPIExecutor.ExecuteGetClientICN(msg.getSenderId()));
                                        result.append(senderICN).append(":\n").append(msg.getText()).append("\n").append(msg.getSendDate()).append("\n\n");
                                    }
                                }
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        MSGText.setText(result.toString());
                                    }
                                });
                            }
                        }
                        MainActivity.MainAPIExecutor.startPinging();
                    }
                }).start();
            }
        });
    }
}