package com.ultima.democlient001;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Timer;
import java.util.TimerTask;

public class ServerConnection {
    private Socket socket;
    private OutputStream ServerOut;
    private InputStream ServerIn;
    private long SecondsToClose = 30;
    private Timer TimerToClose;
    private InetSocketAddress HostAddress;

    private synchronized void SkipSecond() {
        SecondsToClose--;
    }

    private void WriteByte(byte Data) {
        try {
            ServerOut.write(Data);
            SecondsToClose = 30;
        } catch (Exception UnknownException) {
            SecondsToClose = 0;
        }
    }

    private byte[] ReadByte() {
        try {
            while (!(ServerIn.available() > 0)) {
                if (!(SecondsToClose > 0)) {
                    return null;
                }
            }
            byte[] result = new byte[1];
            if (ServerIn.read(result) == 1) {
                SecondsToClose = 30;
                return result;
            } else return null;
        } catch (Exception UnknownException) {
            return null;
        }
    }

    private boolean WriteIntString(byte[] Data) {
        try {
            ServerOut.write(ByteOperations.IntToBytes(Data.length));
            ServerOut.write(Data);
            SecondsToClose = 30;
            return true;
        } catch (Exception UnknownException) {
            return false;
        }
    }

    private byte[] ReadInt() {
        try {
            int ReadIntBytes = 0;
            while (ReadIntBytes < 4) {
                if (ServerIn.available() > ReadIntBytes) {
                    ReadIntBytes = ServerIn.available();
                    SecondsToClose = 30;
                }
                if (!(SecondsToClose > 0)) return null;
            }
            byte[] Result = new byte[4];
            if (ServerIn.read(Result) != 4) return null;
            SecondsToClose = 30;
            return Result;
        } catch (Exception UnknownException) {
            return null;
        }
    }

    public ServerConnection(String ip, int port) {
        socket = new Socket();
        HostAddress = new InetSocketAddress(ip, port);
    }

    public APIExecutor HandShake(String Password) {
        try {
            socket.connect(HostAddress, 30000);
            ServerOut = socket.getOutputStream();
            ServerIn = socket.getInputStream();
            TimerToClose = new Timer();
            TimerToClose.schedule(new TimerTask() {
                @Override
                public void run() {
                    SkipSecond();
                }
            }, 0, 1000);
            byte[] ServerId = ReadInt();
            if(ServerId == null){
                socket.close();
                TimerToClose.cancel();
                return null;
            }
            if(ServerId[0] != 51 || ServerId[1] != 57 || ServerId[2] != Codes.VERSION){
                socket.close();
                TimerToClose.cancel();
                return null;
            }
            if(ServerId[3] == Codes.BASIC_YES){
                if(Password == null){
                    WriteByte(Codes.BASIC_NO);
                    socket.close();
                    TimerToClose.cancel();
                    return null;
                }
                else{
                    WriteByte(Codes.BASIC_YES);
                    if(!WriteIntString(ByteOperations.Get_Bytes_By_String_UTF_8(Password))){
                        socket.close();
                        TimerToClose.cancel();
                        return null;
                    }
                    byte[] result = ReadByte();
                    if(result == null){
                        socket.close();
                        TimerToClose.cancel();
                        return null;
                    }
                    if(result[0] != Codes.BASIC_OK){
                        socket.close();
                        TimerToClose.cancel();
                        return null;
                    }
                    TimerToClose.cancel();
                    return new APIExecutor(socket, ServerOut, ServerIn);
                }
            }
            else if(ServerId[3] == Codes.BASIC_NO){
                WriteByte(Codes.BASIC_YES);
                byte[] result = ReadByte();
                if(result == null){
                    socket.close();
                    TimerToClose.cancel();
                    return null;
                }
                if(result[0] != Codes.BASIC_OK){
                    socket.close();
                    TimerToClose.cancel();
                    return null;
                }
                TimerToClose.cancel();
                return new APIExecutor(socket, ServerOut, ServerIn);
            }
        } catch (Exception UnknownException) {
            if(TimerToClose != null)    TimerToClose.cancel();
        }
        return null;
    }
}
