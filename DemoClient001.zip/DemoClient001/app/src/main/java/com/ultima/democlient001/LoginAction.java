package com.ultima.democlient001;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginAction extends AppCompatActivity {
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_action);
        getSupportActionBar().hide();
        context = getApplicationContext();
        Button Login = findViewById(R.id.continue_from_login);
        EditText EditICN = findViewById(R.id.edit_icn_login);
        EditText EditPassword = findViewById(R.id.edit_password_login);
        ProgressBar PBar = findViewById(R.id.login_waiting_bar);
        View.OnClickListener LoginListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ICN = EditICN.getText().toString();
                String Password = EditPassword.getText().toString();
                if(!(ICN.equals("") || Password.equals(""))) {
                    PBar.setVisibility(ProgressBar.VISIBLE);
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            MainActivity.MainAPIExecutor.stopPinging();
                            byte loginResult = MainActivity.MainAPIExecutor.ExecuteLogin(ICN, Password);
                            if (loginResult == LocalCodes.SUCCESS) {
                                MainActivity.MainAPIExecutor.startPinging();
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        PBar.setVisibility(ProgressBar.INVISIBLE);
                                        Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(LoginAction.this, MainAuthActivity.class);
                                        startActivity(intent);
                                    }
                                });
                            } else {
                                MainActivity.MainAPIExecutor.ExecuteDisconnect();
                                MainActivity.MainAPIExecutor.StopProcess();
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        PBar.setVisibility(ProgressBar.INVISIBLE);
                                        Toast.makeText(context, "Error, please try again", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(LoginAction.this, MainActivity.class);
                                        startActivity(intent);
                                    }
                                });
                            }
                        }
                    }).start();
                }
            }
        };
        Login.setOnClickListener(LoginListener);
    }
}