package com.ultima.democlient001;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class SearchGroupActivity extends AppCompatActivity {
    private Context context;
    private List<Long> ids;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search_action);
        getSupportActionBar().hide();
        context = getApplicationContext();
        Button AddButton = findViewById(R.id.add_searched_button);
        ImageButton SearchButton = findViewById(R.id.start_search_button);
        EditText EditICN = findViewById(R.id.edit_icn_search);
        TextView ShowIds = findViewById(R.id.id_view);
        ids = new ArrayList<>();
        SearchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ICN = EditICN.getText().toString();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        MainActivity.MainAPIExecutor.stopPinging();
                        byte[] id = MainActivity.MainAPIExecutor.ExecuteGetGroupId(ByteOperations.Get_Bytes_By_String_UTF_8(ICN));
                        MainActivity.MainAPIExecutor.startPinging();
                        if(id != null){
                            ids.add(ByteOperations.BytesToLong(id));
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    String latest = ShowIds.getText().toString();
                                    ShowIds.setText(String.format("%sid: %s\n\n", latest, String.valueOf(ByteOperations.BytesToLong(id))));
                                }
                            });
                        }
                    }
                }).start();
            }
        });
        AddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ids != null){
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                Thread.sleep(1000);
                                MainActivity.MainAPIExecutor.stopPinging();
                                for(Long id : ids){
                                    String ICN = ByteOperations.Get_String_UTF_8(MainActivity.MainAPIExecutor.ExecuteGetGroupICN(id));
                                    MainAuthActivity.PTR.addGroup(ICN);
                                }
                                MainActivity.MainAPIExecutor.startPinging();
                            }   catch(Exception UnknownException){}
                        }
                    }).start();
                    Intent intent = new Intent(SearchGroupActivity.this, MainAuthActivity.class);
                    startActivity(intent);
                }
            }
        });
    }
}
