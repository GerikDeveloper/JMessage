package com.ultima.democlient001;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class GroupItemAdapter extends RecyclerView.Adapter<GroupItemAdapter.ItemViewHolder> {
    public static List<String> GroupsICN;
    private static int countHolders;
    public GroupItemAdapter(List<String> ItemsICN){
        countHolders = 0;
        GroupsICN = ItemsICN;
    }
    @Override
    public ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        int layoutId = R.layout.group_item;
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(layoutId, parent, false);
        ItemViewHolder holder = new ItemViewHolder(view);
        countHolders++;
        return holder;
    }

    @Override
    public void onBindViewHolder(ItemViewHolder holder, int position) {
        holder.bind(GroupsICN.get(position));
    }

    @Override
    public int getItemCount() {
        return GroupsICN.size();
    }

    class ItemViewHolder extends RecyclerView.ViewHolder{
        TextView ICNView;
        public ItemViewHolder(View itemView) {
            super(itemView);
            ICNView = itemView.findViewById(R.id.group_item_name);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(MainAuthActivity.PTR, GroupActivity.class);
                    GroupActivity.groupICN = ICNView.getText().toString();
                    MainAuthActivity.PTR.startActivity(intent);
                }
            });
        }
        void bind(String ICN){
            ICNView.setText(ICN);
        }
    }
}
