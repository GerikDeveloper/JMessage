package com.ultima.democlient001;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class ChooseAuthorizeAction extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.choose_authorize_action);
        getSupportActionBar().hide();
        Button RegisterButton = findViewById(R.id.start_register_button);
        Button LoginButton = findViewById(R.id.start_login_button);
        RegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ChooseAuthorizeAction.this, RegisterAction.class);
                startActivity(intent);
            }
        });
        LoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ChooseAuthorizeAction.this, LoginAction.class);
                startActivity(intent);
            }
        });
    }
}
