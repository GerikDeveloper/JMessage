package com.ultima.democlient001;

public class TextMSG {
    private String Text;
    private long SenderId;
    private String SendDate;

    public TextMSG(String text, long id, String date) {
        Text = text;
        SenderId = id;
        SendDate = date;
    }

    public String getText() {
        return Text;
    }

    public String getSendDate() {
        return SendDate;
    }

    public long getSenderId() {
        return SenderId;
    }

    public void setText(String text) {
        Text = text;
    }

    public void setSendDate(String date) {
        SendDate = date;
    }

    public void setSenderId(long id) {
        SenderId = id;
    }
}
