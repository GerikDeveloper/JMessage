package com.ultima.democlient001;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Timer;
import java.util.TimerTask;

public class APIExecutor {
    private Socket socket;
    private OutputStream ServerOut;
    private InputStream ServerIn;
    private long SecondsToClose = 30;
    private Timer TimerToClose;
    private boolean isAuthorized = false;
    private long Id;
    private String clientICN;
    private boolean isPinging = false;

    private synchronized void clearTimer() {
        SecondsToClose = 30;
    }

    public Long getId(){
        byte[] id = ExecuteGetClientId(clientICN);
        if(id == null) return null;
        return ByteOperations.BytesToLong(id);
    }

    public boolean StopProcess() {
        try {
            isPinging = false;
            if (ServerOut != null) ServerOut.close();
            if (ServerIn != null) ServerIn.close();
            if (TimerToClose != null) TimerToClose.cancel();
            if (socket != null) socket.close();
            ServerOut = null;
            ServerIn = null;
            TimerToClose = null;
            socket = null;
        } catch (Exception DisconnectException) {
            return false;
        }
        return true;
    }

    private synchronized void SkipSecond() {
        SecondsToClose--;
    }

    public APIExecutor(Socket ConnectionSocket, OutputStream ConnectionOut, InputStream ConnectionIn) {
        socket = ConnectionSocket;
        ServerOut = ConnectionOut;
        ServerIn = ConnectionIn;
        TimerToClose = new Timer();
        TimerToClose.schedule(new TimerTask() {
            @Override
            public void run() {
                SkipSecond();
            }
        }, 0, 1000);
    }

    private byte[] ReadByte() {
        try {
            while (!(ServerIn.available() > 0)) {
                if (!(isConnected())) {
                    return null;
                }
            }
            byte[] result = new byte[1];
            if (ServerIn.read(result) == 1) {
                clearTimer();
                return result;
            } else return null;
        } catch (Exception UnknownException) {
            return null;
        }
    }

    private byte[] ReadInt() {
        try {
            int ReadIntBytes = 0;
            while (ReadIntBytes < 4) {
                if (ServerIn.available() > ReadIntBytes) {
                    ReadIntBytes = ServerIn.available();
                    clearTimer();
                }
                if (!(isConnected())) return null;
            }
            byte[] Result = new byte[4];
            if (ServerIn.read(Result) != 4) return null;
            clearTimer();
            return Result;
        } catch (Exception UnknownException) {
            return null;
        }
    }

    private byte[] ReadLong() {
        try {
            int ReadLongBytes = 0;
            while (ReadLongBytes < 8) {
                if (ServerIn.available() > ReadLongBytes) {
                    ReadLongBytes = ServerIn.available();
                    clearTimer();
                }
                if (!(isConnected())) return null;
            }
            byte[] Result = new byte[8];
            if (ServerIn.read(Result) != 8) return null;
            clearTimer();
            return Result;
        } catch (Exception UnknownException) {
            return null;
        }
    }

    private byte[] ReadIntString() {
        try {
            int ReadIntStringLen = 0;
            while (ReadIntStringLen < 4) {
                if (ServerIn.available() > ReadIntStringLen) {
                    ReadIntStringLen = ServerIn.available();
                    clearTimer();
                }
                if (!(isConnected())) return null;
            }
            byte[] IntStringLen = new byte[4];
            if (ServerIn.read(IntStringLen) != 4) return null;
            clearTimer();
            byte[] IntString = new byte[ByteOperations.BytesToInt(IntStringLen)];
            int ReadIntStringBytes = 0;
            while (ReadIntStringBytes < ByteOperations.BytesToInt(IntStringLen)) {
                if (ServerIn.available() > ReadIntStringBytes) {
                    ReadIntStringBytes = ServerIn.available();
                    clearTimer();
                }
                if (!(isConnected())) return null;
            }
            if (ServerIn.read(IntString) != ByteOperations.BytesToInt(IntStringLen)) return null;
            clearTimer();
            return IntString;
        } catch (Exception UnknownException) {
            return null;
        }
    }

    private boolean WriteByte(byte Data) {
        try {
            ServerOut.write(Data);
            clearTimer();
            return true;
        } catch (Exception UnknownException) {
            return false;
        }
    }

    private boolean WriteInt(int Data) {
        try {
            ServerOut.write(ByteOperations.IntToBytes(Data));
            clearTimer();
            return true;
        } catch (Exception UnknownException) {
            return false;
        }
    }

    private boolean WriteLong(long Data) {
        try {
            ServerOut.write(ByteOperations.LongToBytes(Data));
            clearTimer();
            return true;
        } catch (Exception UnknownException) {
            return false;
        }
    }

    private boolean WriteIntString(byte[] Data) {
        try {
            ServerOut.write(ByteOperations.IntToBytes(Data.length));
            ServerOut.write(Data);
            clearTimer();
            return true;
        } catch (Exception UnknownException) {
            return false;
        }
    }

    public boolean isConnected() {
        return SecondsToClose > 0;
    }

    public boolean ExecutePing() {
        try {
            if (!WriteByte(Codes.BASIC_PING)) return false;
            byte[] Result = ReadByte();
            if (Result == null) return false;
            return (Result[0] == Codes.BASIC_OK);
        } catch (Exception UnknownException) {
            return false;
        }
    }

    public void startPinging() {
        isPinging = true;
        Timer Ping = new Timer();
        Ping.schedule(new TimerTask() {
            @Override
            public void run() {
                if (isPinging) {
                    if (!ExecutePing()) this.cancel();
                } else this.cancel();
            }
        }, 0, 1000);
    }

    public byte ExecuteRegister(String ICN, String Password, String Email, String Description) {
        if (!WriteByte(Codes.ACCOUNT_REG)) return LocalCodes.IO_ERROR;
        byte[] canReg = ReadByte();
        if (canReg == null) return LocalCodes.IO_ERROR;
        if (canReg[0] == Codes.BASIC_NO) return LocalCodes.FORBIDDEN;
        if (canReg[0] != Codes.BASIC_YES) return LocalCodes.UNKNOWN_ERROR;
        if (!WriteIntString(ByteOperations.Get_Bytes_By_String_UTF_8(ICN)))
            return LocalCodes.IO_ERROR;
        if (!WriteIntString(ByteOperations.Get_Bytes_By_String_UTF_8(Password)))
            return LocalCodes.IO_ERROR;
        if (!WriteIntString(ByteOperations.Get_Bytes_By_String_UTF_8(Email)))
            return LocalCodes.IO_ERROR;
        if (!WriteIntString(ByteOperations.Get_Bytes_By_String_UTF_8(Description)))
            return LocalCodes.IO_ERROR;
        byte[] wasReg = ReadByte();
        if (wasReg == null) return LocalCodes.IO_ERROR;
        if (wasReg[0] == Codes.REG_RESULT_ERR_ICN_TAKEN) return LocalCodes.ICN_TAKEN;
        if (wasReg[0] == Codes.REG_RESULT_ERR_EMAIL_TAKEN) return LocalCodes.EMAIL_TAKEN;
        if (wasReg[0] == Codes.BASIC_OK){
            clientICN = ICN;
            return LocalCodes.SUCCESS;
        }
        else return LocalCodes.UNKNOWN_ERROR;
    }

    public byte ExecuteLogin(String ICN, String Password) {
        if (!WriteByte(Codes.ACCOUNT_LOGIN)) return LocalCodes.IO_ERROR;
        if (!WriteIntString(ByteOperations.Get_Bytes_By_String_UTF_8(ICN)))
            return LocalCodes.IO_ERROR;
        if (!WriteIntString(ByteOperations.Get_Bytes_By_String_UTF_8(Password)))
            return LocalCodes.IO_ERROR;
        byte[] wasLogin = ReadByte();
        if (wasLogin == null) return LocalCodes.IO_ERROR;
        if (wasLogin[0] == Codes.BASIC_OK){
            clientICN = ICN;
            return LocalCodes.SUCCESS;
        }
        else return LocalCodes.UNKNOWN_ERROR;
    }

    public byte ExecuteCreateGroup(String ICN, String Description, int DefaultMemberStatus, long AdminId, long[] MemberIds) {
        if (!WriteByte(Codes.GR_CREATE_GROUP)) return LocalCodes.IO_ERROR;
        byte[] canCreate = ReadByte();
        if (canCreate == null) return LocalCodes.IO_ERROR;
        if (canCreate[0] != Codes.BASIC_OK) return LocalCodes.UNKNOWN_ERROR;
        if (!WriteIntString(ByteOperations.Get_Bytes_By_String_UTF_8(ICN)))
            return LocalCodes.IO_ERROR;
        if (!WriteIntString(ByteOperations.Get_Bytes_By_String_UTF_8(Description)))
            return LocalCodes.IO_ERROR;
        if (!WriteInt(DefaultMemberStatus)) return LocalCodes.IO_ERROR;
        if (!WriteInt(MemberIds.length + 1)) return LocalCodes.IO_ERROR;
        if (!WriteLong(AdminId)) return LocalCodes.IO_ERROR;
        for (long MemberId : MemberIds) {
            if (!WriteLong(MemberId)) return LocalCodes.IO_ERROR;
        }
        byte[] wasCreate = ReadByte();
        if (wasCreate == null) return LocalCodes.IO_ERROR;
        if (wasCreate[0] == Codes.BASIC_OK) return LocalCodes.SUCCESS;
        if (wasCreate[0] == Codes.GR_RESULT_ERR_ICN_TAKEN) return LocalCodes.ICN_TAKEN;
        else return LocalCodes.UNKNOWN_ERROR;
    }

    public byte[] ExecuteGetClientId(String ICN) {
        if (!WriteByte(Codes.UNF_GET_ID_BY_ICN)) return null;
        if (!WriteIntString(ByteOperations.Get_Bytes_By_String_UTF_8(ICN))) return null;
        byte[] canReadResult = ReadByte();
        if (canReadResult == null) return null;
        if (canReadResult[0] == Codes.UNF_OK_FOUND) return ReadLong();
        else return null;
    }

    public byte ExecuteSendMSG(long GroupId, String Data) {
        if (!WriteByte(Codes.SM_SEND_MSG)) return LocalCodes.IO_ERROR;
        if (!WriteLong(GroupId)) return LocalCodes.IO_ERROR;
        byte[] canSend = ReadByte();
        if (canSend == null) return LocalCodes.IO_ERROR;
        if (canSend[0] != Codes.SM_OK_CAN_SEND) return LocalCodes.UNKNOWN_ERROR;
        if (!WriteByte(Codes.MSG_TYPE_TEXT)) return LocalCodes.IO_ERROR;
        if (!WriteIntString(ByteOperations.Get_Bytes_By_String_UTF_8(Data)))
            return LocalCodes.IO_ERROR;
        byte[] wasSend = ReadByte();
        if (wasSend == null) return LocalCodes.IO_ERROR;
        if (wasSend[0] == Codes.SM_MSG_WAS_SENT) return LocalCodes.SUCCESS;
        return LocalCodes.UNKNOWN_ERROR;
    }

    public TextMSG ExecuteGetMSG(long GroupId, long MSGId) {
        if (!WriteByte(Codes.GM_GET_MSG)) return null;
        if (!WriteLong(GroupId)) return null;
        if (!WriteLong(MSGId)) return null;
        byte[] wasFound = ReadByte();
        if (wasFound == null) return null;
        if (wasFound[0] != Codes.GM_OK) return null;
        byte[] SenderId = ReadLong();
        if (SenderId == null) return null;
        byte[] SendDate = ReadIntString();
        if (SendDate == null) return null;
        byte[] MSGType = ReadByte();
        if (MSGType == null) return null;
        if (MSGType[0] != Codes.MSG_TYPE_TEXT) return null;
        byte[] Data = ReadIntString();
        if (Data == null) return null;
        return new TextMSG(ByteOperations.Get_String_UTF_8(Data), ByteOperations.BytesToLong(SenderId), ByteOperations.Get_String_UTF_8(SendDate));
    }

    public long[] ExecuteGetMSGIds(long GroupId) {
        if (!WriteByte(Codes.GM_GET_MSG_IDS)) return null;
        if (!WriteLong(GroupId)) return null;
        byte[] canRead = ReadByte();
        if (canRead == null) return null;
        if (canRead[0] != Codes.GM_OK) return null;
        byte[] MSGIdsCount = ReadLong();
        if (MSGIdsCount == null) return null;
        long[] Result = new long[(int) ByteOperations.BytesToLong(MSGIdsCount)];
        for (long ReadIds = 0; ReadIds < ByteOperations.BytesToLong(MSGIdsCount); ReadIds++) {
            byte[] ReadId = ReadLong();
            if (ReadId == null) return null;
            Result[(int) ReadIds] = ByteOperations.BytesToLong(ReadId);
        }
        return Result;
    }

    public byte[] ExecuteGetClientICN(long ClientId) {
        if (!WriteByte(Codes.UNF_GET_ICN)) return null;
        if (!WriteLong(ClientId)) return null;
        byte[] wasFound = ReadByte();
        if (wasFound == null) return null;
        if (wasFound[0] != Codes.UNF_OK_FOUND) return null;
        return ReadIntString();
    }

    public byte[] ExecuteGetGroupICN(long GroupId) {
        if (!WriteByte(Codes.GR_GET_ICN)) return null;
        if (!WriteLong(GroupId)) return null;
        byte[] wasFound = ReadByte();
        if (wasFound == null) return null;
        if(wasFound[0] != Codes.GR_OK_FOUND) return null;
        return ReadIntString();
    }

    public byte[] ExecuteGetGroupId(byte[] ICN) {
        if (!WriteByte(Codes.GR_GET_ID)) return null;
        if (!WriteIntString(ICN)) return null;
        byte[] wasFound = ReadByte();
        if (wasFound == null) return null;
        if(wasFound[0] != Codes.GR_OK_FOUND) return null;
        return ReadLong();
    }

    public byte ExecuteDisconnect() {
        if (!WriteByte(Codes.BASIC_DISCONNECT)) return LocalCodes.IO_ERROR;
        byte[] res = ReadByte();
        if (res == null) return LocalCodes.IO_ERROR;
        if (res[0] == Codes.BASIC_OK) return LocalCodes.SUCCESS;
        else return LocalCodes.UNKNOWN_ERROR;
    }

    public void stopPinging() {
        isPinging = false;
    }


}
